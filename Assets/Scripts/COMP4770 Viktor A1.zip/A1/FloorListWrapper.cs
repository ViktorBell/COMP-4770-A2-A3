using A1;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class FloorListWrapper
{
    public List<Floor> floorTileList; //stores a list of floor tiles that comprise the entire floor environment
    public List<Floor> filthiestFloorSection;
    public Transform targetDirtyFloorSection;

    public FloorListWrapper() {
        floorTileList = new List<Floor>();
        filthiestFloorSection = new List<Floor>();
        targetDirtyFloorSection = null;
    }

    //Sets the floorList of this object to the entire floor that makes up the 'Environment'
    public void setFloorTileList() {

        floorTileList = CleanerManager.Floors;
    
    }

    //Sets the filthiestFloorSection List to the dirtiest section of the floor
    public void setDirtiestAreaList(List<Floor> dirtiestFloorSection) { 
        
        filthiestFloorSection = dirtiestFloorSection;
    
    }

    //Sets the transform that will be used to move the agent to the dirtiest area which needs to be cleaned
    public void setLocationToBeCleaned() { 
        
        targetDirtyFloorSection = filthiestFloorSection[0].transform;
    
    }

    
 
}
